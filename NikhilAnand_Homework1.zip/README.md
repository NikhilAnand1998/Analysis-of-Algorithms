**Author: Nikhil Anand
**Date: 6/30/2018
**Files Uploaded: insertsort.cpp, insertTime.cpp, mergesort.cpp, mergeTime.cpp, README.md
**Instructions: The insertsort.cpp and mergesort.cpp sort the data from data.txt and output the sorted data to insert.out and merge.out respectively.
** mergeTime.cpp and insertTime.cpp just need to be compiled normally (ex: g++ mergeTime.cpp) and they will print out the size and time for all values between 5000-70000
** incrementing by 5000. In order to average my data points I ran the program 3 times and averaged the results in my excel tables.
